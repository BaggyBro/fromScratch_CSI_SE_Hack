import React from 'react'

export const Logout = () => {
    return (
        <div>
            Logout
        </div>
    )
}


