import React from 'react'

export const Home = () => {
    return (
        <div>
            This is Home
        </div>
    )
}


